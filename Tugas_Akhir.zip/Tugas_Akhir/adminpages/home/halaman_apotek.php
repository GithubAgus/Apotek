
<?php 
session_start();
include "../koneksi/koneksi.php";
include "../templates/header.php"; 
?>



<div class="right_col" role="main">
                 <div class="row tile_count">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total Data Obat</span>
          
              <div class="count">20</div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i> Total Data Obat</span>
           
            
             
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-clock-o"></i>Total Data Suplier </span>
              <div class="count">50</div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i> Total Data Suplier</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i>Total Stock Obat </span>
              <div class="count green">20</div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i> Total Stock Obat</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Daftar Pengguna</span>
              <div class="count">15</div>
              <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i></i> Daftar Pengguna</span>
            </div>


          </div>

<!-- /top tiles 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/jquery.slim.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="assets/font/bootstrap-icons.css">
    <style>
body {
  font-family: "Lato", sans-serif;
}

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: lightblue ;
  overflow-x: hidden;
  padding-top: 20px;
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 16px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover, .dropdown-btn:hover {
  color: #f1f1f1;
}

/* Add an active class to the active dropdown button */
.active {
  background-color: green;
  color: white;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}

/* Some media queries for responsiveness */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 12px;}
}
</style>
</head>
<body>
    <nav>
    <div class="sidenav">
    <img src="../img/horizon.png" height="13%">
    <h4><center>Sistem Informasi Apotek</center></h4>
    <h4><center>Kelompok 1</center></h4>
  <hr/>
  <button class="dropdown-btn">Master Data ⏬
    <i class="fa fa-arrow-down" aria-hidden="true"></i>
  </button>
  <div class="dropdown-container">
    <a href="../obat/input_obat.php" target="isi">Data Obat</a><br>
    <a href="../suplier/input_suplier.php" target="isi">Data Suplier</a>
  </div>
              
  <button class="dropdown-btn">Stock ⏬    
    <i class="fa fa-arrow-down" aria-hidden="true"></i>
  </button>
  <div class="dropdown-container">
    <a href="../stock_obat/lihat_stock.php" target="isi">Data Stock Obat</a>
  </div>
  <button class="dropdown-btn">Transaksi ⏬    
    <i class="fa fa-arrow-down" aria-hidden="true"></i>
  </button>
  <div class="dropdown-container">
    <a href="../penjualan/form_penjualan.php" target="isi">Penjualan</a>
  </div>
  <button class="dropdown-btn">Pengguna 
    <i class="fa fa-arrow-down" aria-hidden="true"></i>
  </button>
  <div class="dropdown-container">
    <a href="../pengguna/lihat_pengguna.php" target="isi">Pengguna</a>
  
  </div>
  
  <a href='../logout.php' target="_parent">Logout </a>
  </div>
    </nav>

    <hr />
    <center><iframe class="konten" name="isi" style="border:none"; width="900" height="900">

</center></iframe>
    <script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>
</body>
</html>
--!>
<?php include "../templates/footer.php"; ?>