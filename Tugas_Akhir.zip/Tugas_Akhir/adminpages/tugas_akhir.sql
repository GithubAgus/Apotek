-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Jun 2021 pada 16.28
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugas_akhir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE `obat` (
  `id_obat` varchar(50) NOT NULL,
  `nama_obat` varchar(50) NOT NULL,
  `suplier` text NOT NULL,
  `jenis_obat` varchar(50) NOT NULL,
  `stock_obat` varchar(50) NOT NULL,
  `expired_date` date NOT NULL,
  `harga_beli` varchar(50) NOT NULL,
  `harga_jual` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`, `suplier`, `jenis_obat`, `stock_obat`, `expired_date`, `harga_beli`, `harga_jual`) VALUES
('A00002', 'bodrex', 'PT.Indo Alkes', 'kapsul', '3', '2021-07-10', '3000', '5000'),
('A00003', 'bodrex', 'PT.Indo Alkes', 'kapsul', '1', '2021-07-02', '3000', '5000'),
('A00004', 'remasil', 'PT.Penta Valent', 'kapsul', '1', '2021-07-11', '3000', '5000'),
('A00005', 'betadin', 'PT.Indo Alkes', 'cairan', '1', '2021-06-25', '2000\r\n', '5000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `username` varchar(25) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `akses` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`username`, `nama`, `no_hp`, `password`, `akses`) VALUES
('T0001', 'harun', '89675', '12', 'Admin'),
('user', 'harun', '89675', '1234', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` varchar(15) NOT NULL,
  `id_obat` varchar(15) NOT NULL,
  `jumlah_beli` int(20) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `suplier`
--

CREATE TABLE `suplier` (
  `id_suplier` varchar(50) NOT NULL,
  `nama_suplier` text NOT NULL,
  `alamat` text NOT NULL,
  `tlp` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `suplier`
--

INSERT INTO `suplier` (`id_suplier`, `nama_suplier`, `alamat`, `tlp`, `email`) VALUES
('1', 'PT.Indo Alkes', 'perumahan permana adimix blok D1 no 29 rengasdengklok karawang barat', '082113494332', 'agus.priyanto157@yahoo.com'),
('2', 'PT.Indo Alkes', 'perumahan permana adimix blok D1 no 29 rengasdengklok karawang barat', '082113494332', 'agus.priyanto157@yahoo.com'),
('A0001', 'PT.Penta Valent', 'perumahan permana adimix blok D1 no 29 rengasdengklok karawang barat', '082113494332', 'agus.priyanto157@yahoo.com');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`);

--
-- Indeks untuk tabel `suplier`
--
ALTER TABLE `suplier`
  ADD PRIMARY KEY (`id_suplier`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `penjualan_ibfk_1` FOREIGN KEY (`id_penjualan`) REFERENCES `pengguna` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
