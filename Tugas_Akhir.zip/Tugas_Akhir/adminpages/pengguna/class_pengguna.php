<?php
  class pengguna{
  	private $db;

  	function __construct ($koneksi){
  		$this->db=$koneksi;
  	}

  	public function lihatdata($query){
  		$stmt = $this->db->prepare($query);
  		$stmt ->execute();
          print "JUMLAH BARIS YANG DITEMUKAN :".$stmt->rowCount()."<br>";
  		while ($row=$stmt->fetch(PDO::FETCH_ASSOC))
  		 {
  			echo "<tr>
                <td>".$row['username']."</td>
                <td>".$row['nama']."</td>
				<td>".$row['no_hp']."</td>
                <td>".$row['password']."</td>
                <td>".$row['akses']."</td>
  				</tr>";
  		}
  	}
  }

?>