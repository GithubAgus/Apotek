<?php
include '../koneksi/koneksi.php';
         $username=$_POST['username'];
         $nama=$_POST['nama'];
         $no_hp=$_POST['no_hp'];
         $password=$_POST['password'];
         $akses=$_POST['akses'];

$sql=$koneksi->prepare("UPDATE pengguna SET nama='$nama', no_hp='$no_hp', password='$password', akses='$akses'
 WHERE username='$username'");
$sql->execute();

header("location:lihat_pengguna.php");
 
?>