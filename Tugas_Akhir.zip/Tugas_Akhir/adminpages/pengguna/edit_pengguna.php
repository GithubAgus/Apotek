<!DOCTYPE html>
<html>
<head>
	<title></title>
   
   <style>

td{
					height: 20px;
                    border:none;
                    padding: 5px;

				}
				tr{margin: 5px;}
				input[type=text]{
					height: 30px;
					width: 300px;
				}
 				select{
   				    height: 30px;
					width: 300px;	
				}

				input[type=date]{
					height: 30px;
					width: 300px;
				}
				fieldset{
					border-radius: 5px;
					width: 80%;
				}
				legend{
					padding:  10px;

				}
                button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
</style>
</head>
<body>
<center>

 <?php
 include '../koneksi/koneksi.php';
    $username=$_GET['username'];
    $sql=$koneksi->prepare("SELECT * FROM pengguna WHERE username='$username'");
    $sql->execute();
    while($d=$sql->fetch()){?>
    <fieldset>
 <form action="update_pengguna.php" method="POST">
 <legend><h1>FROM EDIT DATA</h1></legend>
 <table>					   
						
						<tr>
							<td>Username</td>
							<td><input type=text name=username  placeholder="Masukan Username" requiredvalue="<?php echo $d['username'];?>"></td>
						</tr>
						<tr>
							<td>Nama Lengkap</td>
							<td><input type=text name=nama placeholder="nama"required value="<?php echo $d['nama'];?>"></td>
						</tr>
						<tr>
							<td>No.Hp</td>
							<td><input type=text name=no_hp placeholder="No. Hp" required value="<?php echo $d['no_hp'];?>"></td>
						</tr>
						<tr>
							<td>Password</td>
							<td><input type=password name=password  placeholder="Password" requiredvalue="<?php echo $d['password'];?>"></td>
						</tr>
						<tr>
							<td>Akses</td>
							<td>
								<select name='akses' value="<?php echo $d['akses'];?>">
							      <option value='Admin'>Admin</option>
							      <option value='User'>User</option> 							    
							    </select>
							 </td>   

						</tr>						
						<tr>
                        <td colspan="2">
                        <button type="submit" name="submit" >Simpan</button>						
                        </td>
                        </tr>
					</table>
				
				 </form>
                 </fieldset>
                 <?php } ?>
                 </center>
                
</body>
</html>