<?php
     include '../koneksi/koneksi.php';
      
      $username=$_GET['username'];
       $sql="DELETE FROM pengguna WHERE username='$username'";
       $query=$koneksi->prepare($sql);
       $query->execute();
       if(!$query){
           header("location:lihat_pengguna.php");
           }
           else{
          header("location:lihat_pengguna.php");
      }
    

    ?>