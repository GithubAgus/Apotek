<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <link rel='stylesheet' type='text/css' href='style.css'>
    <title></title>
    <style>

td{
					height: 20px;
                    border:none;
                    padding: 5px;

				}
				tr{margin: 5px;}
				input[type=text]{
					height: 30px;
					width: 300px;
				}
 				select{
   				    height: 30px;
					width: 300px;	
				}
				button{
					border: 1;
					border-radius: 3px;
					color: black;
					width: 100px; 
					height: 30px; 
					font-weight: bold;
				}
				input[type=date]{
					height: 30px;
					width: 300px;
				}
				fieldset{
					border-radius: 5px;
					width: 80%;
				}
				legend{
					padding:  10px;

				}
				button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
</style>
</head>
<body>
<center>
				<fieldset>
			<legend><h2><center>Form Pengguna</center></h2></legend>
				<form action=lihat_pengguna.php method=post>	
					
						 <table>					   
						
						<tr>
							<td>Username</td>
							<td><input type=text name=username  placeholder="Masukan Username" required></td>
						</tr>
						<tr>
							<td>Nama Lengkap</td>
							<td><input type=text name=nama placeholder="nama"required></td>
						</tr>
						<tr>
							<td>No.Hp</td>
							<td><input type=text name=no_hp placeholder="No. Hp" required></td>
						</tr>
						<tr>
							<td>Password</td>
							<td><input type=password name=password  placeholder="Password" required></td>
						</tr>
						<tr>
							<td>Akses</td>
							<td>
								<select name='akses'>
							      <option value='Admin'>Admin</option>							    
							    </select>
							 </td>   

						</tr>						
						<tr>
							<td><button type="submit" name="submit">simpan</button>
							<button><a href='lihat_pengguna.php'>lihat data</button></a>
							<button><a href='../index.php'>Kembali</button></a>
							</td>						
						</tr>
				
					</table>
				 </form>
			</fieldset>
			</center>
</body>
</html>