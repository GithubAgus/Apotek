<?php
class Logout
{
	function DoLogout() 
		{ 
			session_start(); //mengecek apakah udah ada yg login apa belum
			session_unset();
			unset($_SESSION['no_hp']);
			unset($_SESSION['tipe']);

			echo '<script type="text/javascript" >'; 
			echo 'window.location="index.php";'; 
			echo '</script>'; 
		}	
}
?>
