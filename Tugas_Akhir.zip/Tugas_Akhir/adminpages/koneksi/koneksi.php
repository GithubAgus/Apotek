<?php
 try {
  	   $koneksi= new PDO ("mysql:host=localhost; dbname=tugas_akhir","root","",
		 array(PDO::ATTR_PERSISTENT=>true));
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
  
?>