<script>
function sum() {
      var txtFirstNumberValue = document.getElementById('total').value;
      var txtSecondNumberValue = document.getElementById('uang_bayar').value;
      var result = parseInt(txtSecondNumberValue) - parseInt(txtFirstNumberValue);
      if (!isNaN(result)) {
         document.getElementById('uang_kembali').value = result;
      }

}



function cekbayar()
{
	
	if (document.formbayar.uang_bayar.value=='')
			{
				alert('Periksa Kembali Inputan');
				return false;				
			}
	if (document.formbayar.uang_kembali.value < 0)
			{
				alert('Periksa Kembali Inputan');
				return false;				
			}
if ((document.formbayar.uang_bayar.value != '' ) && (document.formbayar.uang_kembali.value > 0))
		{	
 setTimeout(function()
 {
  window.location = "form_transaksi.php";
 },200);
}
}
</script>

<?php
include "../koneksi/koneksi.php";

echo "<h3>Daftar Pembelian</h3>";

$ambil = mysqli_query($koneksi,"select * from transaksi where kode_transaksi = '$kode_otomatis'");
$baris = mysqli_num_rows($ambil);

echo "<table border=1>";
echo "<tr><th>Nomor</th><th>Kode Transaksi</th><th>Kode Barang</th><th>Nama Barang</th><th>Jumlah Beli</th><th>Harga Beli</th><th>Tanggal</th>";

$total = 0;
for($i=1;$i<=$baris;$i++)
{
$data = mysqli_fetch_array($ambil);

$ambil2 = mysqli_query($koneksi,"select * from barang where kode_barang = '$data[kode_barang]'");	
$data2 = mysqli_fetch_array($ambil2);
$harga = $data['jumlah_beli'] * $data2['harga_barang'];
$total += $harga;
$tanggal = $data['tanggal'];
echo "<tr align=center><td>$i</td><td>$data[kode_transaksi]</td><td>$data[kode_barang]</td><td>$data2[nama_barang]</td><td>$data[jumlah_beli]</td>
<td>$harga</td><td>$data[tanggal]</td><td><a href='konfirmasi_hapus_transaksi.php?kode_transaksi=$data[kode_transaksi]&kode_barang=$data[kode_barang]'
		onclick='return confirm(\"Apakah Yakin Akan Dihapus ?\")'>Hapus</a></td></tr>";
}



echo "<form name=formbayar target='_blank' method=post action=cetak_struk.php>";
echo "<input type=hidden name=kode value='$kode_otomatis'>";
echo "<input type=hidden name=tanggal value=$tanggal>";
echo "<tr align=center><th colspan=5>Jumlah Bayar</th><td align><input type=text value='$total' name='total' id='total' readonly=readonly></td></tr>";
echo "<tr align=center><th colspan=5>Uang Bayar</th><td align><input type='text' onkeyup='sum();' name='uang_bayar' id='uang_bayar'></td></tr>";
echo "<tr align=center><th colspan=5>Uang Kembali</th><td align><input type=text name='uang_kembali' id='uang_kembali' readonly=readonly></td></tr>";
echo "</table>";
echo "<input type=submit name=bayar value='Bayar' onclick=' return cekbayar();'>";
echo "</form>";
?>