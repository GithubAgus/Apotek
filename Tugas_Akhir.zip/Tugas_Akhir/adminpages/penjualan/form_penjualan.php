<!DOCTYPE html>

<center>
<?php
include "../koneksi/koneksi.php";

if(isset($_GET['id_obat'])) 
	{
		$kode_otomatis = $_GET['id_obat'];
	}
	else 
	{	
	
		$carikode = $koneksi->Prepare("SELECT max(id_penjualan)  from penjualan");
		$carikode->execute();
		$datakode = $carikode->fetch();
	if ($datakode) {
   	$nilaikode = substr($datakode[0], 1);
   	// menjadikan $nilaikode ( int )
   	$id_obat = (int) $nilaikode;
   	// setiap $kode di tambah 1
   	$id_obat = $id_obat + 1;
   	$kode_otomatis = "A".str_pad($id_obat, 4, "0", STR_PAD_LEFT);
  		} else {
   	$kode_otomatis = "A00001";
  		}
  	}	
	
	//Membuat Select Box Kode Barang dan Nama Barang
	$ambildata = $koneksi->prepare( "SELECT id_obat, nama_obat from obat");
	$baris = $ambildata->rowCount();
		echo "<datalist name='id_obat' id='barang'>";
	for($i=1;$i<=$baris;$i++) 
	{
	$data = mysqli_fetch_array($ambildata);
	echo "<option value='$data[kode_barang]'>$data[nama_barang]</option>";
}
echo "</datalist>";	
$tanggal = date('Y-m-d');

echo '<form name="form" method="post" action="simpan_transaksi.php">';
echo "<table>";	
echo "<tr><td>Kode Transaksi</td><td>:</td><td>";
echo '<input type=text name="id_penjualan"  value="'.$kode_otomatis.'" readonly=readonly></td></tr>';
echo "<tr><td>Nama Obat</td><td>:</td><td>";
echo '<input type="text" autocomplete="off" class="form-control" name="id_obat"  required></td></tr>';
echo "<tr><td>Jumlah Beli</td><td>:</td><td>";
echo '<input type=text autocomplete="off" class="form-control" name="jumlah_beli" id="jumlah_beli" required></td></tr>';
echo "<tr><td>Tanggal Pembelian</td><td>:</td><td>";
echo "<input type=text readonly=readonly class='form-control' name='tanggal' id='tanggal' value=$tanggal></td></tr>";
echo "<table>";
echo "<input type=submit value=Simpan><input type=reset value=Batal>";
echo "</form>";
include "../penjualan/lihat_penjualan.php";


?>
</center>
</html>