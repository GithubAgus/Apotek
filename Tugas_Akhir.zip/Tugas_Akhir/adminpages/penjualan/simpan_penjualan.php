<?php

include "../koneksi/koneksi.php";

$id_penjualan = $_POST['id_penjualan'];
$id_obat = $_POST['id_obat'];
$jumlah_beli = $_POST['jumlah_beli'];
$tanggal = $_POST['tanggal'];

$simpan = "INSERT INTO penjualan ('','id_penjualan','id_obat','jumlah_beli','tanggal') 
            VALUES('$id_penjualan','$id_obat','$jumlah_beli','$tanggal')";
            $query = $koneksi->query($simpan);
if(!$simpan)
{
	echo "<script>alert('Data Gagal Disimpan');history.go(-1);</script>";
}
else
{
	echo "<script>alertz('Data Berhasil Disimpan');</script>";
	echo "<script>window.location='form_penjualan.php?kode=$id_penjualan'</script>";
}

?>