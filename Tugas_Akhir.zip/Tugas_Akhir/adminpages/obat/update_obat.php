<?php
include '../koneksi/koneksi.php';
         $id_obat=$_POST['id_obat'];
         $nama_obat=$_POST['nama_obat'];
         $suplier=$_POST['suplier'];
         $jenis_obat=$_POST['jenis_obat'];
         $stock_obat=$_POST['stock_obat'];
         $expired_date=$_POST['expired_date'];
         $harga_beli=$_POST['harga_beli'];
         $harga_jual=$_POST['harga_jual'];

$sql=$koneksi->prepare("UPDATE obat SET nama_obat='$nama_obat', suplier='$suplier', jenis_obat='$jenis_obat', stock_obat='$stock_obat', expired_date='$expired_date', harga_beli='$harga_beli
', harga_jual='$harga_jual' WHERE id_obat='$id_obat'");
$sql->execute();

header("location:lihat_obat.php");
 
?>