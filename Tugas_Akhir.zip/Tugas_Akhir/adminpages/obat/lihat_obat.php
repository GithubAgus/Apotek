<!DOCTYPE html>
<html>
<head>
	<title></title>
  <style>
  button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
         </style>
</head>
<body>
<center>
<h1>JENIS-JENIS OBAT</h1>
   <table border=1  width='88%'>
              <tr class=header>
                <th bgcolor='skyblue'>No</th>
                <th bgcolor='skyblue'>Kode Obat</th>
                <th bgcolor='skyblue'>Nama Obat</th>
                <th bgcolor='skyblue'align='center'>Suplier</th>
                <th bgcolor='skyblue'>Jenis Obat</th>
                <th bgcolor='skyblue'>Stock Obat</th>
                <th bgcolor='skyblue'>Expired Date</th>
                <th bgcolor='skyblue'>Harga Beli</th>
                <th bgcolor='skyblue'>Harga Jual</th>
                <th bgcolor='skyblue' align='center' width='10%'>Keterangan</th>
              </tr>
            <?php
   include "class_obat.php";
   include '../koneksi/koneksi.php';
   $query=$koneksi->prepare("SELECT * FROM obat");
   $query->execute();
   $data=$query->fetchAll();
   $no = 1;
   foreach ($data as $value) {?>
        <td><?= $no++; ?></td>
       <th><?php echo $value['id_obat'];?></th>
       <th><?php echo $value['nama_obat'];?></th>
       <th><?php echo $value['suplier'];?></th>
       <th><?php echo $value['jenis_obat'];?></th>
       <th><?php echo $value['stock_obat'];?></th>
       <th><?php echo $value['expired_date'];?></th>
       <th><?php echo $value['harga_beli'];?></th>
       <th><?php echo $value['harga_jual'];?></th>
      <th><a href="hapus_obat.php?id_obat=<?php echo $value['id_obat'];?>" onclick="return confirm('Apakah Yakin mau di hapus?');" name="hapus"><img src=../icon/hapus.png height='20' width='20'></a>
      <a href="edit_obat.php?id_obat=<?php echo $value['id_obat'];?>"><img src=../icon/edit.png height='20' width='20' ></a></th>
     </tr>
   
   <?php }

       //fungsi INSERT DATA//
     if(isset($_POST['submit'])){
         $id_obat=$_POST['id_obat'];
         $nama_obat=$_POST['nama_obat'];
         $suplier=$_POST['suplier'];
         $jenis_obat=$_POST['jenis_obat'];
         $stock_obat=$_POST['stock_obat'];
         $expired_date=$_POST['expired_date'];
         $harga_beli=$_POST['harga_beli'];
         $harga_jual=$_POST['harga_jual'];
        $sql = "INSERT INTO obat (id_obat, nama_obat, suplier, jenis_obat, stock_obat, expired_date, harga_beli, harga_jual) VALUES('$id_obat', '$nama_obat','$suplier', '$jenis_obat', '$stock_obat', '$expired_date', '$harga_beli', '$harga_jual')";
        $query = $koneksi->query($sql);
          if(!$query){
           header("location:lihat_obat.php");
           }
           else{
          header("location:lihat_obat.php");
      }

    }
   
   ?> 
   <tr>
    <td colspan="10" align='right'>
   <button><a href='../home/halaman_apotek.php'>Kembali</a></button>
   </td>
</tr>       
   </table>
   <br>
</center>
</body>
</html>
