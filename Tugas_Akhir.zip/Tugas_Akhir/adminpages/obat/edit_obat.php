<!DOCTYPE html>
<html>
<head>
	<title></title>
   
   <style>

td{
					height: 20px;
                    border:none;
                    padding: 5px;

				}
				tr{margin: 5px;}
				input[type=text]{
					height: 30px;
					width: 300px;
				}
 				select{
   				    height: 30px;
					width: 300px;	
				}

				input[type=date]{
					height: 30px;
					width: 300px;
				}
				fieldset{
					border-radius: 5px;
					width: 80%;
				}
				legend{
					padding:  10px;

				}
                button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
</style>
</head>
<body>
<center>

 <?php
 include '../koneksi/koneksi.php';
    $id_obat=$_GET['id_obat'];
    $sql=$koneksi->prepare("SELECT * FROM obat WHERE id_obat='$id_obat'");
    $sql->execute();
    while($d=$sql->fetch()){?>
    <fieldset>
 <form action="update_obat.php" method="POST">
 <legend><h1>FROM EDIT DATA</h1></legend>
    <table>
    <tr>
        <td> Kode Obat</td>
        <td> <input type="text" name="id_obat" required placeholder="Masukkan Kode Obat" value="<?php echo $d['id_obat'];?>"></td>
    </tr>
        <tr>
            <td> Nama Obat</td>
            <td> <input type="text" name="nama_obat" required placeholder="Masukkan Nama Obat" value="<?php echo $d['nama_obat'];?>"></td>
        </tr>
            <tr>
                <td>Nama Suplier </td>
                <td><select name="suplier" value="<?php echo $d['suplier'];?>">
                <option></option>
                <option value="PT.Herbal Mandiri">PT.Herbal Mandiri</option>
                <option value="PT.Kimia Farma">PT.Kimia Farma</option>
                <option value="PT.Penta Valent">PT.Penta Valent</option>
                <option value="PT.Indo Alkes">PT.Indo Alkes</option>
                <option value="Lainnya">Lainnya</option></tr>
                </select></td>
            </tr>
                  <tr>
                    <td>Jenis Obat </td>
                    <td><input type="text" name="jenis_obat"required placeholder="Masukkan Jenis Obat" value="<?php echo $d['jenis_obat'];?>"></td>
                  </tr>
                        <tr>
                            <td>Stock Obat </td>
                            <td><input type="text" name="stock_obat"required placeholder="Masukkan Stock Obat" value="<?php echo $d['stock_obat'];?>"></td>
                        </tr>
                                <tr>
                                    <td>Expired Date </td>
                                    <td><input type="date" name="expired_date"required value="<?php echo $d['expired_date'];?>"></td>
                                </tr>
                                        <tr>
                                              <td>Harga Beli </td>
                                              <td><input type="text" name="harga_beli"required placeholder="Masukkan Harga Beli" value="<?php echo $d['harga_beli'];?>"></td>
                                        </tr>
                                                  <tr>
                                                        <td>Harga Jual </td>
                                                        <td><input type="text" name="harga_jual"required placeholder="Masukkan Harga Jual" value="<?php echo $d['harga_jual'];?>"></td>
                                                  </tr>

<tr>
    <td colspan="2">
    <button type="submit" name="submit" >Simpan</button>
    </td>
</tr>
</table>
</form>
</fieldset>
   

<?php } ?>
</center>
</body>
</html>