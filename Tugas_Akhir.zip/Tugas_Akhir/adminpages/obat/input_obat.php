<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
  <meta name="author" content="">
    <title></title>

    <style>

td{
					height: 20px;
                    border:none;
                    padding: 5px;

				}
				tr{margin: 5px;}
				input[type=text]{
					height: 30px;
					width: 300px;
				}
 				select{
   				    height: 30px;
					width: 300px;	
				}

				input[type=date]{
					height: 30px;
					width: 300px;
				}
				fieldset{
					border-radius: 5px;
					width: 80%;
				}
				legend{
					padding:  10px;

				}
                button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }

</style>
</head>
<body>

<center>
<fieldset>
<legend><h1>Input Data Obat</h1></legend>
<form action="lihat_obat.php" method="POST">
<table>
    <tr>
        <td> Kode Obat</td>
        <td> <input type="text" name="id_obat" required placeholder="Masukkan Kode Obat"></td>
    </tr>
        <tr>
            <td> Nama Obat</td>
            <td> <input type="text" name="nama_obat" required placeholder="Masukkan Nama Obat"></td>
        </tr>
            <tr>
                <td>Nama Suplier </td>
                <td><select name="suplier">
                <option></option>
                <option value="PT.Herbal Mandiri">PT.Herbal Mandiri</option>
                <option value="PT.Kimia Farma">PT.Kimia Farma</option>
                <option value="PT.Penta Valent">PT.Penta Valent</option>
                <option value="PT.Indo Alkes">PT.Indo Alkes</option>
                <option value="Lainnya">Lainnya</option></tr>
                </select></td>
            </tr>
                  <tr>
                    <td>Jenis Obat </td>
                    <td><input type="text" name="jenis_obat"required placeholder="Masukkan Jenis Obat"></td>
                  </tr>
                        <tr>
                            <td>Stock Obat </td>
                            <td><input type="text" name="stock_obat"required placeholder="Masukkan Stock Obat"></td>
                        </tr>
                                <tr>
                                    <td>Expired Date </td>
                                    <td><input type="date" name="expired_date"required></td>
                                </tr>
                                        <tr>
                                              <td>Harga Beli </td>
                                              <td><input type="text" name="harga_beli"required placeholder="Masukkan Harga Beli"></td>
                                        </tr>
                                                  <tr>
                                                        <td>Harga Jual </td>
                                                        <td><input type="text" name="harga_jual"required placeholder="Masukkan Harga Jual"></td>
                                                  </tr>

<tr>
    <td colspan="2">
    <button type="submit" name="submit">Simpan</button>
	<button ><a href='lihat_obat.php'>Lihat data</a></button>
    <button><a href='../home/halaman_apotek.php'>Kembali</a></button>
    </td>
</tr>
</table>
   </form>
   </center>
   </fieldset>
</body>
</html>