<?php
  class obat{
  	private $db;

  	function __construct ($koneksi){
  		$this->db=$koneksi;
  	}

  	public function lihatdata($query){
  		$stmt = $this->db->prepare($query);
  		$stmt ->execute();
          print "JUMLAH BARIS YANG DITEMUKAN :".$stmt->rowCount()."<br>";
  		while ($row=$stmt->fetch(PDO::FETCH_ASSOC))
  		 {
  			echo "<tr>
                <td>".$row['id_obat']."</td>
                <td>".$row['nama_obat']."</td>
				<td>".$row['suplier']."</td>
                <td>".$row['jenis_obat']."</td>
                <td>".$row['stock_obat']."</td>
				<td>".$row['harga_beli']."</td>
				<td>".$row['harga_jual']."</td>
  				</tr>";
  		}
  	}
  }

?>