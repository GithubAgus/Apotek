<?php
     include '../koneksi/koneksi.php';
      
      $id_obat=$_GET['id_obat'];
       $sql="DELETE FROM obat WHERE id_obat='$id_obat'";
       $query=$koneksi->prepare($sql);
       $query->execute();
       if(!$query){
           header("location:lihat_obat.php");
           }
           else{
          header("location:lihat_obat.php");
      }
    

    ?>