<html>
		  <head>
				<style type=text/css>
				body{
					 font-family:sans-serif;
					 background:url('logo.jpg');
					 background-size:cover;
					 background-repeat:no-repeat;
					} 
					form{
					  font-family: arial;
					  background-color: rgb(255,255,255,0.7);
					  width: 300px;
					  margin: 180px auto;
					  padding: 30px;
					  text-align: right;
					  color: #2D2D2D;
					  border-radius: 40px 10px;
					  box-shadow: 2px 2px 7px #393939;
					}
					input{
					  margin: 10px;
					}
					input.login{
					  background-color: #0096FF;
					  color: #E7E7E7;
					  font-family: verdana;
					  font-weight: bold;
					  border-radius: 10px;
					  padding: 5px 10px;
					  margin: 30px 10px auto 0px;
					  text-transform: uppercase;
					  transition: .2s;
					}
					input.login:hover{
					  background-color: #93A4B0;
					  color: #CDCDCD;
					}
					p{
					  text-align:center;
					  margin: 50px auto;
					  margin-top: 10px;
					  padding: 10px;
					  font-weight: bold;
					  color: #0101A6;
					  font-family: verdana;
					  background-color: #0096FF;
					  border-radius: 20px;
					}
													 
				 div.login{ 
					 box-sizing: border-box; 
					 padding: 20px;
					 width: 300px;
					 height: 300px;
					 margin-top: 0px;
					 background: white;
				 }
				 b{
					 color: #476DF9;
					 border-bottom: 2px solid #476DF9;
					 padding: 10px;
				 }
				 input {
					 width: 250px;
					 border: none;
					 border-bottom: 1px solid #476DF9;
					 padding: 5px;
				 }
				 button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
				</style>
				<title>Selamat Datang</title>
		  </head>
		  <body>
			  <form action=login.php method=post>
				  <center>
					<div class=login>
						<b>Menu Login</b><br><br><br>
						<input type=text name=username placeholder="Masukan Username" required><br><br>
						<input type=password name=password placeholder="Masukan kata sandi" required><br><br>
						<button type=submit>Login</button>
						<button ><a href='./pengguna/input_pengguna.php'>SigUp</a></button>
					</div>
		    </center>
		    </form>
		  </body>
		  </html>