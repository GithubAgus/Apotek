<?php
  require_once "class_akses.php";
  class Login
  {
	  var $nama,$no_hp,$username, $password, $akses;
	    function __construct()
	    {
		  $this->koneksi = new Akses();// Memanggil class Akses
	      $this->koneksi->bukaDB();// Memanggil method BukaDB untuk open database
	      
	  
			if(isset($_POST['nama']))
			{
				$this->nama = $_POST['nama'];
			}
			if(isset($_POST['username']))
			{
				$this->username = $_POST['username'];
			}
			if(isset($_POST['password']))
			{
				$this->password = $_POST['password'];
			}
			if(isset($_POST['no_hp']))
			{
				$this->no_hp = $_POST['no_hp'];
			}
			if(isset($_POST['akses']))
			{
				$this->akses = $_POST['akses'];
			}
		}
		function __destruct()
		{
			$this->koneksi=new Akses();// Memanggil class Akses
		    $this->koneksi->TutupDB();// Memanggil method BukaDB untuk open database
		}

		function DoLogin()
		{
			$login=mysqli_query($this->koneksi->link,"select * from pengguna where 
			username = '$this->username'");
			$data = mysqli_fetch_array($login);
				if (($this->username != $data['username']) || ( $this->password != $data['password']))
				{
					echo "<script>alert('username atau sandi salah')</script>"; echo "<script> window.history.back() </script>";
				}
				else
				{
					//daftarkan id jika user dan password benar
					session_start();
					$_SESSION['username'] = $data['username'];
					$_SESSION['akses'] = $data['akses'];
					$this->username = $_SESSION['username'];
					$this->akses = $_SESSION['akses'];
					 if($data['akses'] == 'Admin')
					 {
					  header("Location:./home/halaman_apotek.php");  
					 }else
					
					 if($data['akses'] == 'User')
					 {
					  header("Location:..");   	 
					 }
				}
		}
	
  }
?>
