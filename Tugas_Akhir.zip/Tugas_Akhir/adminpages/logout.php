<?php
include"class_logout.php";
$logout=new Logout;
$logout-> Dologout();
?>
