  <!DOCTYPE html>
<html>
<head>
	<title>Selamat Datang</title>
  <style>
  button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
         </style>
</head>
<body>
<center>
<h1>DAFTAR SUPLIER</h1>
<table border=1  width='88%'>
              <tr>
                <th bgcolor='skyblue'>No</th>
                <th bgcolor='skyblue'>Kode Suplier</th>
                <th bgcolor='skyblue'>Nama Suplier</th>
                <th bgcolor='skyblue'>Alamat</th>
                <th bgcolor='skyblue'>No Telepon</th>
                <th bgcolor='skyblue'>Email</th>
                <th bgcolor='skyblue'>Keterangan</th>
              </tr>
            <?php
   include "class_suplier.php";
   include '../koneksi/koneksi.php';
   $query=$koneksi->prepare("SELECT * FROM suplier");
   $query->execute();
   $data=$query->fetchAll();
   $no = 1;
   foreach ($data as $value) {?>
     <tr>
        <td><?= $no++; ?></td>
       <th><?php echo $value['id_suplier'];?></th>
       <th><?php echo $value['nama_suplier'];?></th>
       <th><?php echo $value['alamat'];?></th>
       <th><?php echo $value['tlp'];?></th>
       <th><?php echo $value['email'];?></th>
       <th><a href="hapus_suplier.php?id_suplier=<?php echo $value['id_suplier'];?>" onclick="return confirm('Apakah Yakin mau di hapus?');" name="hapus"><img src=../icon/hapus.png height='20' width='20'></a><a href="edit_suplier.php?id_suplier=<?php echo $value['id_suplier'];?>"><img src=../icon/edit.png width=20 height=20></a>
     </tr>
   
   <?php }

       //fungsi INSERT DATA//
     if(isset($_POST['submit'])){
         $id_suplier=$_POST['id_suplier'];
         $nama_suplier=$_POST['nama_suplier'];
         $alamat=$_POST['alamat'];
         $tlp=$_POST['tlp'];
         $email=$_POST['email'];
        $sql = "INSERT INTO suplier (id_suplier, nama_suplier, alamat, tlp, email) VALUES('$id_suplier', '$nama_suplier','$alamat', '$tlp', '$email')";
        $query = $koneksi->query($sql);
          if(!$query){
           header("location:lihat_suplier.php");
           }
           else{
          header("location:lihat_suplier.php");
      }

    }
   
   ?>  
   <tr>
    <td colspan="10" align='right'>
   <button><a href='../home/halaman_apotek.php'>Kembali</a></button>
   </td>
</tr>        
   </table>
   <br>
</center>
</body>
</html>