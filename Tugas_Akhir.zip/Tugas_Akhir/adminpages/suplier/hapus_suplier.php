<?php
     include '../koneksi/koneksi.php';
      
      $id_suplier=$_GET['id_suplier'];
       $sql="DELETE FROM suplier WHERE id_suplier='$id_suplier'";
       $query=$koneksi->prepare($sql);
       $query->execute();
       if(!$query){
           header("location:lihat_suplier.php");
           }
           else{
          header("location:lihat_suplier.php");
      }
    

    ?>