<?php
  class suplier{
  	private $db;

  	function __construct ($koneksi){
  		$this->db=$koneksi;
  	}

  	public function lihatdata($query){
  		$stmt = $this->db->prepare($query);
  		$stmt ->execute();
          print "JUMLAH BARIS YANG DITEMUKAN :".$stmt->rowCount()."<br>";
  		while ($row=$stmt->fetch(PDO::FETCH_ASSOC))
  		 {
  			echo "<tr>
                <td>".$row['id_suplier']."</td>
                <td>".$row['nama_suplier']."</td>
				<td>".$row['alamat']."</td>
                <td>".$row['tlp']."</td>
                <td>".$row['email']."</td>
  				</tr>";
  		}
  	}
  }

?>