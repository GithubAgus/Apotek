<?php
include '../koneksi/koneksi.php';
         $id_suplier=$_POST['id_suplier'];
         $nama_suplier=$_POST['nama_suplier'];
         $alamat=$_POST['alamat'];
         $tlp=$_POST['tlp'];
         $email=$_POST['email'];

$sql=$koneksi->prepare("UPDATE suplier SET nama_suplier='$nama_suplier', alamat='$alamat', tlp='$tlp', email='$email'
 WHERE id_suplier='$id_suplier'");
$sql->execute();

header("location:lihat_suplier.php");
 
?>