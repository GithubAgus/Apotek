<!DOCTYPE html>
<html>
<head>
	<title></title>
   
   <style>

td{
					height: 20px;
                    border:none;
                    padding: 5px;

				}
				tr{margin: 5px;}
				input[type=text]{
					height: 30px;
					width: 300px;
				}
 				select{
   				    height: 30px;
					width: 300px;	
				}

				input[type=date]{
					height: 30px;
					width: 300px;
				}
				fieldset{
					border-radius: 5px;
					width: 80%;
				}
				legend{
					padding:  10px;

				}
            button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
</style>
</head>
<body>
<center>
 <?php
 include '../koneksi/koneksi.php';
    $id_suplier=$_GET['id_suplier'];
    $sql=$koneksi->prepare("SELECT * FROM suplier WHERE id_suplier='$id_suplier'");
    $sql->execute();
    while($d=$sql->fetch()){?>
    <fieldset>
 <form action="update_suplier.php" method="POST">
 	<h4>FROM EDIT DATA</h4>
    <table> 
   <tr>
    <td>Kode Suplier</td>
    <td><input type="text" name="id_suplier"required placeholder="Masukkan Kode Suplier" value="<?php echo $d['id_suplier'];?>"></td>
   </tr>
        <tr>
          <td> Nama Suplier </td>
          <td><select name="nama_suplier"required value="<?php echo $d['nama_suplier'];?>">
          <option></option>
          <option value="PT.Herbal Mandiri">PT.Herbal Mandiri</option>
          <option value="PT.Kimia Farma">PT.Kimia Farma</option>
          <option value="PT.Penta Valent">PT.Penta Valent</option>
          <option value="PT.Indo Alkes">PT.Indo Alkes</option>
          <option value="Lainnya">Lainnya</option>
          </select></td>
        </tr>
             <tr>
                <td>Alamat </td>
                <td><input type="text" name="alamat"required placeholder="Masukkan Alamat Suplier" value="<?php echo $d['alamat'];?>"></td>
             </tr>
                  <tr>
                  <td> No Telepon </td>
                  <td><input type="text" name="tlp"required placeholder="Masukkan Nomor Telepon" value="<?php echo $d['tlp'];?>"></td>
                  </tr>
                        <tr>
                            <td>Email </td>
                            <td><input type="text" name="email"required placeholder="Masukkan Email" value="<?php echo $d['email'];?>"></td>
                        </tr>
    <tr>
    <td colspan="2">
    <button type="submit" name="submit">Simpan</button>
    </td>
    </tr>
</table>
</form>
</fieldset>
<?php } ?>
</center>
</body>
</html>