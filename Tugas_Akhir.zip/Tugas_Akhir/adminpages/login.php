<?php
include"class_login.php";
$login=new Login;
$login->DoLogin();
?>

