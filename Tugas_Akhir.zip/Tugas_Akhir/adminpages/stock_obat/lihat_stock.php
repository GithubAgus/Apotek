<!DOCTYPE html>
<html>
<head>
	<title></title>
  <style>
  button{
					 background: #476DF9;
					 color: white;
					 width: 125px;
					 height: 28px;
					 border: 1px solid #476DF9;
					 
				 }
         </style>
</head>
<body><center>
<h1>DATA STOCK OBAT</h1>
   <table border=1 align='right' width='88%'>
              <tr>
                <th bgcolor='skyblue'>No</th>
                <th bgcolor='skyblue'>Kode Obat</th>
                <th bgcolor='skyblue'>Nama Obat</th>
                <th bgcolor='skyblue'>Expired Date</th>
                <th bgcolor='skyblue'>Stock_Obat</th>
                <th bgcolor='skyblue'>Nama Suplier</th>
                <th bgcolor='skyblue'>Jenis Obat</th>
              </tr>
            <?php
   include "class_stock.php";
   include '../koneksi/koneksi.php';
   $query=$koneksi->prepare("SELECT id_obat, nama_obat, expired_date, stock_obat, suplier, jenis_obat from obat");
   $query->execute();
   $data=$query->fetchAll();
   $no = 1;
   foreach ($data as $value) {?>
     <tr>
        <td><?= $no++; ?></td>
       <th><?php echo $value['id_obat'];?></th>
       <th><?php echo $value['nama_obat'];?></th>
       <th><?php echo $value['expired_date'];?></th>
       <th><?php echo $value['stock_obat'];?></th>
       <th><?php echo $value['suplier'];?></th>
       <th><?php echo $value['jenis_obat'];?></th>
     </tr>
   
   <?php }
   
   ?>   
   <tr>
    <td colspan="10" align='right'>
   <button><a href='../home/halaman_apotek.php'>Kembali</a></button>
   </td>
</tr>           
   </table>
</center>
</body>
</html>