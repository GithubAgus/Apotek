<?php
require_once"class_login.php";
class Akses
{
	var $username,$password,$host,$namaDb,$link;
	
	function __construct()
	{
		$this->username='root';
		$this->password = '';
		$this->host='localhost';
		$this->namaDB='tugas_akhir';
		$this->link=mysqli_connect("$this->host","$this->username",
		"$this->password","$this->namaDB");
	}
	//koenksi Db
	function BukaDB()
	{
		if(!$this->link)
		{
			echo"eror: unable to connect to mysql".PHP_EOL;
			exit;
		}
	}
	function TutupDB()
	{
		mysqli_close($this->link);
		if(!$this->link)
		{
			echo"eror: unable to connect to mysql".PHP_EOL;
			exit;
		}
	}
	
	function CekSesi()
	{
		session_start();
		
		if(!isset($_SESSION['tipe']))
		{
			echo"<script>alert('akses di tolak');</script>";
			echo"<script>window.open('index.php','_top');</script>";
		 exit;
		}
		else
		{
            $tipe=$_SESSION['tipe'];
            
		}
	}
}
